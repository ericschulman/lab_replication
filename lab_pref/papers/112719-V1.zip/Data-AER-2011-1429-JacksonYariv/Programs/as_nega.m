% ---------------------------------------------------------------------------
% Sessions 5 and 6
% Characterization into types
% With a in [-1,1]
% ---------------------------------------------------------------------------

clc
clear
data=importdata('data_for_matlab');

diary off;evalc('delete log_nega.txt');diary('log_nega.txt');diary on;clear ans

% key variables
% ---------------------------
max_a=1;      %...    maximum a
max_k=6;      %...    maximum k (inclusive, 1 to 6)
dis_a=0.050;  %...    how discrete a
ut='a1astd';  %...    definition of utility std/var/a1astd/a1avar/a1aAV

% defining utility function
% u(a,data,option)
% Note: in std() and var() functions second argument 0/1 determines whether
% divide by N-1 (0) or by N (1)
% ---------------------------
if strcmp(ut,'std')==1
    u=@(a,d,o) mean(d(:,5+o*3:7+o*3),2)-a*std(d(:,5+o*3:7+o*3),1,2);
    us='u=mean-a*std';
elseif strcmp(ut,'var')==1
    u=@(a,d,o) mean(d(:,5+o*3:7+o*3),2)-a*var(d(:,5+o*3:7+o*3),1,2);
    us='u=mean-a*var';
elseif strcmp(ut,'a1astd')==1
    u=@(a,d,o) a*mean(d(:,5+o*3:7+o*3),2)-(1-a)*std(d(:,5+o*3:7+o*3),1,2);
    us='u=a*mean-(1-a)*std';
elseif strcmp(ut,'a1avar')==1
    u=@(a,d,o) a*mean(d(:,5+o*3:7+o*3),2)-(1-a)*var(d(:,5+o*3:7+o*3),1,2);
    us='u=a*mean-(1-a)*var';
elseif strcmp(ut,'a1aAV')==1
    u=@(a,d,o) a*mean(d(:,5+o*3:7+o*3),2)-(1-a)*(abs(d(:,5+o*3)-d(:,6+o*3))+abs(d(:,5+o*3)-d(:,7+o*3))+abs(d(:,6+o*3)-d(:,7+o*3)));
    us='u=a*mean-(1-a)*AV';
end

% values of a
% ---------------------------
A=[-max_a:dis_a:max_a]';
num_as=size(A,1);
As=['A=[' num2str(min(A)) ',' num2str(A(2,1)) ',...,' num2str(max(A)) ']'];

% predicted data
% data_pred (periods X levels of a)
% ---------------------------
data_pred(1:size(data,1),1:num_as)=NaN;
num_ind=0;
for ai=1:num_as
    a=A(ai,1);
    data_pred(:,ai)=u(a,data,0)<u(a,data,1);
    data_pred(:,ai)=data_pred(:,ai)+0.5*(u(a,data,0)==u(a,data,1));
    num_ind=num_ind+sum(u(a,data,0)==u(a,data,1));
    clear a
end
clear ai

% determining matches for score
% data_sc (matches X levels of a)
% ---------------------------
data_sc(1:size(data,1),1:num_as)=NaN;
for ai=1:num_as
    a=A(ai,1);
    data_sc(:,ai)=data(:,4)==data_pred(:,ai);
    data_sc(:,ai)=data_sc(:,ai)+0.5*(data_pred(:,ai)==0.5);
    clear a
end
clear ai

% results matrices
% ---------------------------
res(1:24+36,1:num_as)=NaN;
res_cl(1:24+36,1:2)=NaN;
res_row=0;
for client=0:35
    res_row=res_row+1;
    score=sum(data_sc(1+client*14:14+client*14,:),1)/14;
    session=5;
    res(res_row,:)=score;
    res_cl(res_row,1:2)=[session,client];
    clear score session
end
for client=0:23
    res_row=res_row+1;
    score=sum(data_sc(504+1+client*38:504+38+client*38,:),1)/38;
    session=6;
    res(res_row,:)=score;
    res_cl(res_row,1:2)=[session,client];
    clear score session
end
clear client res_row

% maximum scores
% ---------------------------
res_max(1:24+36,1:5)=NaN;
for res_row=1:60
    [max_val,max_i]=max(res(res_row,:));
    res_max(res_row,1)=max_val;
    res_max(res_row,2)=size(find(res(res_row,:)==max_val),2);
    res_max(res_row,3)=A(min(find(res(res_row,:)==max_val)),1);
    res_max(res_row,4)=mean(A(find(res(res_row,:)==max_val)));
    res_max(res_row,5)=A(max(find(res(res_row,:)==max_val)),1);
    clear max_val max_i
end
clear res_row

% optimal scores
% ---------------------------
kmaxv(1:max_k,1)=NaN;
kmaxi(1:max_k,1)=NaN;

% optimal scores, k=1
% ---------------------------
if max_k>=1
    kvars1=combntns(A,1);
    kvars1(:,2:4)=NaN;
    kvars1a(1:size(kvars1,1),1:2)=NaN;
    for i=1:size(kvars1,1)
        k1=kvars1(i,1);
        k1i=find(A==k1);
        kvars1(i,2)=60;
        kvars1(i,3)=mean(res(:,k1i));
        kvars1(i,4)=mean(res(:,k1i));
        kvars1a(i,1)=60;
        kvars1a(i,2)=mean(res(:,k1i));;
        clear k1 k1i
    end
    clear i
    [kmaxv(1,1) kmaxi(1,1)]=max(kvars1(:,3));
    disp(['optimal scores k=1 done']);diary off;diary on;
end

% optimal scores, k=2
% ---------------------------
if max_k>=2
    kvars2=combntns(A,2);
    kvars2(:,3:7)=NaN;
    kvars2a(1:size(kvars2,1),1:4)=NaN;
    for i=1:size(kvars2,1)
        k1=kvars2(i,1);k2=kvars2(i,2);
        k1i=find(A==k1);k2i=find(A==k2);
        kvars2(i,3:5)=0;
        scores=[res(:,k1i),res(:,k2i)];
        maxscores=max(scores,[],2);
        scores_maxi=scores==[maxscores,maxscores];
        kvars2(i,5)=mean(maxscores);
        kvars2(i,3:4)=sum(scores_maxi./[sum(scores_maxi,2),sum(scores_maxi,2)]);
        kvars2(i,6:7)=sum((scores_maxi.*scores)./[sum(scores_maxi,2),sum(scores_maxi,2)])./kvars2(i,3:4);
        kvars2a(i,1:2)=sum(scores_maxi);
        kvars2a(i,3:4)=sum(scores_maxi.*scores)./sum(scores_maxi);
        clear k1 k2 k1i k2i p scores maxscores scores_maxi
    end
    clear i
    [kmaxv(2,1) kmaxi(2,1)]=max(kvars2(:,5));
    disp(['optimal scores k=2 done']);diary off;diary on;
end

% optimal scores, k=3
% ---------------------------
if max_k>=3
    kvars3=combntns(A,3);
    kvars3(:,4:10)=NaN;
    kvars3a(1:size(kvars3,1),1:6)=NaN;
    for i=1:size(kvars3,1)
        k1=kvars3(i,1);k2=kvars3(i,2);k3=kvars3(i,3);
        k1i=find(A==k1);k2i=find(A==k2);k3i=find(A==k3);
        kvars3(i,4:6)=0;
        scores=[res(:,k1i),res(:,k2i),res(:,k3i)];
        maxscores=max(scores,[],2);
        scores_maxi=scores==[maxscores,maxscores,maxscores];
        kvars3(i,7)=mean(maxscores);
        kvars3(i,4:6)=sum(scores_maxi./[sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2)]);
        kvars3(i,8:10)=sum((scores_maxi.*scores)./[sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2)])./kvars3(i,4:6);
        kvars3a(i,1:3)=sum(scores_maxi);
        kvars3a(i,4:6)=sum(scores_maxi.*scores)./sum(scores_maxi);
        clear k1 k2 k3 k1i k2i k3i p scores maxscores scores_maxi
    end
    clear i
    [kmaxv(3,1) kmaxi(3,1)]=max(kvars3(:,7));
    disp(['optimal scores k=3 done']);diary off;diary on;
end

% optimal scores, k=4
% ---------------------------
if max_k>=4
    kvars4=combntns(A,4);
    kvars4(:,5:13)=NaN;
    kvars4a(1:size(kvars4,1),1:8)=NaN;
    for i=1:size(kvars4,1)
        k1=kvars4(i,1);k2=kvars4(i,2);k3=kvars4(i,3);k4=kvars4(i,4);
        k1i=find(A==k1);k2i=find(A==k2);k3i=find(A==k3);k4i=find(A==k4);
        kvars4(i,5:8)=0;
        scores=[res(:,k1i),res(:,k2i),res(:,k3i),res(:,k4i)];
        maxscores=max(scores,[],2);
        scores_maxi=scores==[maxscores,maxscores,maxscores,maxscores];
        kvars4(i,9)=mean(maxscores);
        kvars4(i,5:8)=sum(scores_maxi./[sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2)]);
        kvars4(i,10:13)=sum((scores_maxi.*scores)./[sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2)])./kvars4(i,5:8);
        kvars4a(i,1:4)=sum(scores_maxi);
        kvars4a(i,5:8)=sum(scores_maxi.*scores)./sum(scores_maxi);
        clear k1 k2 k3 k4 k1i k2i k3i k4i p scores maxscores scores_maxi
    end
    clear i
    [kmaxv(4,1) kmaxi(4,1)]=max(kvars4(:,9));
    disp(['optimal scores k=4 done']);diary off;diary on;
end

% optimal scores, k=5
% ---------------------------
if max_k>=5
    kvars5=combntns(A,5);
    kvars5(:,6:16)=NaN;
    kvars5a(1:size(kvars5,1),1:10)=NaN;
    for i=1:size(kvars5,1)
        k1=kvars5(i,1);k2=kvars5(i,2);k3=kvars5(i,3);k4=kvars5(i,4);k5=kvars5(i,5);
        k1i=find(A==k1);k2i=find(A==k2);k3i=find(A==k3);k4i=find(A==k4);k5i=find(A==k5);
        kvars5(i,6:10)=0;
        scores=[res(:,k1i),res(:,k2i),res(:,k3i),res(:,k4i),res(:,k5i)];
        maxscores=max(scores,[],2);
        scores_maxi=scores==[maxscores,maxscores,maxscores,maxscores,maxscores];
        kvars5(i,11)=mean(maxscores);
        kvars5(i,6:10)=sum(scores_maxi./[sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2)]);
        kvars5(i,12:16)=sum((scores_maxi.*scores)./[sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2)])./kvars5(i,6:10);
        kvars5a(i,1:5)=sum(scores_maxi);
        kvars5a(i,6:10)=sum(scores_maxi.*scores)./sum(scores_maxi);
        clear k1 k2 k3 k4 k5 k1i k2i k3i k4i k5i p scores maxscores scores_maxi
    end
    clear i
    [kmaxv(5,1) kmaxi(5,1)]=max(kvars5(:,11));
    disp(['optimal scores k=5 done']);diary off;diary on;
end

% optimal scores, k=6
% ---------------------------
if max_k>=6
    kvars6=combntns(A,6);
    kvars6(:,7:19)=NaN;
    kvars6a(1:size(kvars6,1),1:12)=NaN;
    for i=1:size(kvars6,1)
        k1=kvars6(i,1);k2=kvars6(i,2);k3=kvars6(i,3);k4=kvars6(i,4);k5=kvars6(i,5);k6=kvars6(i,6);
        k1i=find(A==k1);k2i=find(A==k2);k3i=find(A==k3);k4i=find(A==k4);k5i=find(A==k5);k6i=find(A==k6);
        kvars6(i,7:12)=0;
        scores=[res(:,k1i),res(:,k2i),res(:,k3i),res(:,k4i),res(:,k5i),res(:,k6i)];
        maxscores=max(scores,[],2);
        scores_maxi=scores==[maxscores,maxscores,maxscores,maxscores,maxscores,maxscores];
        kvars6(i,13)=mean(maxscores);
        kvars6(i,7:12)=sum(scores_maxi./[sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2)]);
        kvars6(i,14:19)=sum((scores_maxi.*scores)./[sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2),sum(scores_maxi,2)])./kvars6(i,7:12);
        kvars6a(i,1:6)=sum(scores_maxi);
        kvars6a(i,7:12)=sum(scores_maxi.*scores)./sum(scores_maxi);
        clear k1 k2 k3 k4 k5 k6 k1i k2i k3i k4i k5i k6i p scores maxscores scores_maxi
    end
    clear i
    [kmaxv(6,1) kmaxi(6,1)]=max(kvars6(:,13));
    disp(['optimal scores k=6 done']);diary off;diary on;
end
disp([' '])

% checking calculation of scores by type
% ---------------------------
for k=1:max_k
    eval(['tempv=max(abs(kvars' num2str(k) '(:,' num2str(2*k+1) ')-sum(kvars' num2str(k) '(:,' num2str(k+1) ':' num2str(2*k) ').*kvars' num2str(k) '(:,' num2str(2*k+2) ':' num2str(3*k+1) '),2)/60));'])
    if tempv>=1e-15
        warning(['something wrong in calculation of score by type, k=' num2str(k) ', by ' num2str(tempv) ])
    end
    clear tempv
end
clear k

% displaying results
% ---------------------------
disp(['Maximum score for k types'])
disp(['-------------------------'])
disp([[1:max_k,60]',[kmaxv;mean(res_max(:,1))]])

for k=1:max_k
    disp(['k=' num2str(k) ' types'])
    disp(['---------'])
    eval(['tempk=kvars' num2str(k) '(find(kmaxv(k,1)==kvars' num2str(k) '(:,' num2str(2*k+1) ')),:);'])
    eval(['tempka=kvars' num2str(k) 'a(find(kmaxv(k,1)==kvars' num2str(k) '(:,' num2str(2*k+1) ')),:);'])
    disp(['    optimal k' char(39) 's'])
    eval(['disp(tempk(:,1:' num2str(k) '))'])
    disp(['    distribution of subjects'])
    eval(['disp(tempk(:,' num2str(k+1) ':' num2str(2*k) '))'])
    disp(['    maximal score by type (columns 1:k) and maximal score'])
    eval(['disp([tempk(:,' num2str(2*k+2) ':' num2str(3*k+1) '),tempk(:,' num2str(2*k+1) ')])'])
    disp(['    distribution of subjects and maximal score by type'])
    disp(['    (if subject is of more than one type, then fully belongs to each)'])
    eval(['disp([tempka])'])
    clear tempk tempka
end
clear k

disp(['Correlation of individual optimal a' char(39) 's and corresponding scores'])
disp(['Using min a, average a, max a'])
disp([corr(res_max(:,1),res_max(:,3)),corr(res_max(:,1),res_max(:,4)),corr(res_max(:,1),res_max(:,5))])

save('as')

diary off
%%
% printing results
% ---------------------------
evalc('delete score_results.ps');clear ans
ti={['Average score'] [As ', ' us]};
figure('Visible','off'),plot(A,mean(res),'k.'),title(ti),xlabel('a'),ylabel('score'),grid
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['Average score for session 5'] [As ', ' us]};
figure('Visible','off'),plot(A,mean(res(1:36,:)),'k.'),title(ti),xlabel('a'),ylabel('score'),grid
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['Average score for session 6'] [As ', ' us]};
figure('Visible','off'),plot(A,mean(res(37:end,:)),'k.'),title(ti),xlabel('a'),ylabel('score'),grid
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['a' char(39) 's maximizing scores (if multiple then lowest one)'] [As ', ' us]};
figure('Visible','off'),plot(res_max(:,3),'k.','MarkerSize',20),title(ti),xlabel('client (session 5 and 6)'),ylabel('a'),grid,axis([0 60 -max_a max_a])
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['a' char(39) 's maximizing scores (lowest vs. largest)'] [As ', ' us]};
figure('Visible','off'),axis([0 60 -max_a max_a]),plot([1:1:60],res_max(:,3),'k.',[1:1:60],res_max(:,5),'k.','MarkerSize',15),title(ti),xlabel('client (session 5 and 6)'),ylabel('a'),grid,axis([0 60 -max_a max_a])
for i=1:60
    line([i,i],[res_max(i,3),res_max(i,5)],'LineWidth',1,'Color','k','LineStyle',':')
end
print -f1 -dpsc2 -append score_results;close Figure 1;
clear i ti
ti={['Sorted a' char(39) 's maximizing scores (if multiple then lowest one)'] [As ', ' us]};
figure('Visible','off'),plot(sort(res_max(:,3)),'k.','MarkerSize',20),title(ti),xlabel('client (session 5 and 6)'),ylabel('a'),grid,axis([0 60 -max_a max_a])
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['Sorted a' char(39) 's maximizing scores (if multiple then average one)'] [As ', ' us]};
figure('Visible','off'),plot(sort(res_max(:,4)),'k.','MarkerSize',20),title(ti),xlabel('client (session 5 and 6)'),ylabel('a'),grid,axis([0 60 -max_a max_a])
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['Sorted a' char(39) 's maximizing scores (if multiple then highest one)'] [As ', ' us]};
figure('Visible','off'),plot(sort(res_max(:,5)),'k.','MarkerSize',20),title(ti),xlabel('client (session 5 and 6)'),ylabel('a'),grid,axis([0 60 -max_a max_a])
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['Maximum scores with individual a' char(39) 's'] [As ', ' us]};
figure('Visible','off'),plot(sort(res_max(:,1)),'k.','MarkerSize',20),title(ti),xlabel('client (session 5 and 6)'),ylabel('max score'),grid
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['CDF of maximum scores with individual a' char(39) 's'] [As ', ' us]};x=[0:0.1:1];
figure('Visible','off'),bar(x-0.05,cumsum(histc(res_max(:,1),x))/60),axis([0 1 0 1]),grid,title(ti),xlabel('max score'),ylabel('% of subjects')
print -f1 -dpsc2 -append score_results;close Figure 1;
clear x ti
ti={['PDF of maximum scores with individual a' char(39) 's'] [As ', ' us]};x=[0:0.1:1];
figure('Visible','off'),bar(x-0.05,histc(res_max(:,1),x)/60),axis([0 1 0 1]),grid,title(ti),xlabel('max score'),ylabel('% of subjects')
print -f1 -dpsc2 -append score_results;close Figure 1;
clear x ti
ti={['CDF of optimal a' char(39) 's with individual a' char(39) 's'] [As ', ' us]};x=[-1:0.1:1];colormap('gray');
figure('Visible','off'),bar(x,cumsum(histc(res_max(:,3:5),x))/60),axis([-max_a-0.05 max_a+0.05 0 1]),grid,title(ti),xlabel('optimal a'),ylabel('% of subjects'),legend('min','ave','max','Location','NorthWest'),colormap('gray');cmap=colormap;colormap(flipud(cmap));
print -f1 -dpsc2 -append score_results;close Figure 1;colormap('default');
clear x ti cmap
ti={['PDF of optimal a' char(39) 's with individual a' char(39) 's'] [As ', ' us]};x=[-1:0.1:1];
figure('Visible','off'),bar(x,histc(res_max(:,3:5),x)/60),axis([-max_a-0.05 max_a+0.05 0 1]),grid,title(ti),xlabel('optimal a'),ylabel('% of subjects'),legend('min','ave','max','Location','NorthWest'),colormap('gray');cmap=colormap;colormap(flipud(cmap));
print -f1 -dpsc2 -append score_results;close Figure 1;colormap('default');
clear x ti cmap
ti={['a' char(39) 's maximizing scores (lowest) vs. maximum scores'] [As ', ' us] ['correlation ' num2str(corr(res_max(:,1),res_max(:,3)))]};
figure('Visible','off'),plot(res_max(:,3),res_max(:,1),'k.','MarkerSize',20),title(ti),xlabel('a'),ylabel('score'),grid,axis('equal',[-max_a max_a 0 1])
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['a' char(39) 's maximizing scores (average) vs. maximum scores'] [As ', ' us] ['correlation ' num2str(corr(res_max(:,1),res_max(:,4)))]};
figure('Visible','off'),plot(res_max(:,4),res_max(:,1),'k.','MarkerSize',20),title(ti),xlabel('a'),ylabel('score'),grid,axis('equal',[-max_a max_a 0 1])
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['a' char(39) 's maximizing scores (largest) vs. maximum scores'] [As ', ' us] ['correlation ' num2str(corr(res_max(:,1),res_max(:,5)))]};
figure('Visible','off'),plot(res_max(:,5),res_max(:,1),'k.','MarkerSize',20),title(ti),xlabel('a'),ylabel('score'),grid,axis('equal',[-max_a  max_a 0 1])
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
ti={['Characterization by k types, maximal score'] [As ', ' us]};
figure('Visible','off'),plot([1:max_k+1],[kmaxv;mean(res_max(:,1))],'k.','MarkerSize',15),grid,xlabel('k'),ylabel('maximum score'),title(ti),set(gca,'XTick',[1:max_k+1],'XTickLabel',[1:max_k,60])
print -f1 -dpsc2 -append score_results;close Figure 1;
clear ti
for k=1:max_k
    eval(['tempk=kvars' num2str(k) '(find(kmaxv(k,1)==kvars' num2str(k) '(:,' num2str(2*k+1) ')),:);'])
    eval(['tempk_v=tempk(1,' num2str(k+1) ':' num2str(2*k) ');'])
    eval(['tempk_l=tempk(1,1:' num2str(k) ');'])
    ti={['Characterization by ' num2str(k) ' types, distribution into types'] [As ', ' us]};
    figure('Visible','off'),bar(tempk_v),grid,xlabel('k'),ylabel('number of subjects with given type'),title(ti),set(gca,'XTickLabel',tempk_l),axis([0.5 k+0.5 0 61])
    print -f1 -dpsc2 -append score_results;close Figure 1;
    clear tempk tempk_v tempk_l ti
end
clear k
for k=1:max_k
    eval(['tempk=kvars' num2str(k) '(find(kmaxv(k,1)==kvars' num2str(k) '(:,' num2str(2*k+1) ')),:);'])
    eval(['tempk_v=tempk(1,' num2str(2*k+2) ':' num2str(3*k+1) ');'])
    eval(['tempk_l=tempk(1,1:' num2str(k) ');'])
    ti={['Characterization by ' num2str(k) ' types, score by types'] [As ', ' us]};
    figure('Visible','off'),bar(tempk_v),grid,xlabel('k'),ylabel('average score of subjects with given type'),title(ti),set(gca,'XTickLabel',tempk_l),axis([0.5 k+0.5 0 1])
    print -f1 -dpsc2 -append score_results;close Figure 1;
    clear tempk tempk_v tempk_l ti
end
clear k
for res_row=1:60;
    ti={['Score for client ' num2str(res_cl(res_row,2)) ' and session ' num2str(res_cl(res_row,1))] [As ', ' us]};
    %figure('Visible','off'),plot(A,res(res_row,:),'k.'),title(ti),xlabel('a'),ylabel('score')
    %print -f1 -dpsc2 -append score_results;close Figure 1;
    clear ti
end
clear res_row

! ps2pdf score_results.ps
delete score_results.ps

